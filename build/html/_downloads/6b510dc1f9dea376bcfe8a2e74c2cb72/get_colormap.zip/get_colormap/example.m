%% 1
figure;
pcolor(peaks(50));
shading interp
colorbar;
mycolormap = customcolormap(linspace(0,1,8),mycolor(1,1));
colormap(mycolormap);
exportgraphics(gcf,'001.png','Resolution',600);
%% 2
figure;
pcolor(peaks(50));
shading interp
colorbar;
mycolormap = customcolormap(linspace(0,1,8),mycolor(1,1),10);
colormap(mycolormap);

%% 3
figure;
pcolor(peaks(50));
shading interp
colorbar;
mycolormap = customcolormap([0 0.5 1],[229,245,249;153,216,201;44,162,95]./255);
colormap(mycolormap);

%% 4
figure;
pcolor(peaks(50));
shading interp
colorbar;
mycolormap = customcolormap([0 0.5 1],[229,245,249;153,216,201;44,162,95]./255,10);
colormap(mycolormap);

%% 5
figure;
pcolor(peaks(50));
shading interp
colorbar;
mycolormap = customcolormap([0 0.2 0.3 0.5 0.7 0.8 1],[255,255,255;255,255,255;229,245,249;...
    153,216,201;44,162,95;255,255,255;255,255,255]./255);
colormap(mycolormap);

%% 6
figure;
pcolor(peaks(50));
shading interp
colorbar;
mycolormap = customcolormap([0 0.2 0.3 0.5 0.7 0.8 1],[255,255,255;255,255,255;229,245,249;...
    153,216,201;44,162,95;255,255,255;255,255,255]./255,10);
colormap(mycolormap);

