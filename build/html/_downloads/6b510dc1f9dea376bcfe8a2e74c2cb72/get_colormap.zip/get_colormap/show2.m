clear;clc;

h=tiledlayout(3,4);
h.TileSpacing='compact';
h.Padding='compact';

ax1=nexttile([1 1]);
pcolor(peaks(50));
shading interp
xticklabels('');
yticklabels('');
h=colorbar;
h.TickLabels={};
mycolormap = customcolormap(linspace(0,1,8),mycolor(1,1));
colormap(ax1,mycolormap);

ax2=nexttile([1 1]);
pcolor(peaks(50));
shading interp
xticklabels('');
yticklabels('');
h=colorbar;
h.TickLabels={};
mycolormap = customcolormap(linspace(0,1,8),mycolor(2,1));
colormap(ax2,mycolormap);

ax3=nexttile([1 1]);
pcolor(peaks(50));
shading interp
xticklabels('');
yticklabels('');
h=colorbar;
h.TickLabels={};
mycolormap = customcolormap(linspace(0,1,8),mycolor(3,1));
colormap(ax3,mycolormap);

ax4=nexttile([1 1]);
pcolor(peaks(50));
shading interp
xticklabels('');
yticklabels('');
h=colorbar;
h.TickLabels={};
mycolormap = customcolormap(linspace(0,1,8),mycolor(4,1));
colormap(ax4,mycolormap);

ax5=nexttile([1 1]);
pcolor(peaks(50));
shading interp
xticklabels('');
yticklabels('');
h=colorbar;
h.TickLabels={};
mycolormap = customcolormap(linspace(0,1,8),mycolor(5,1));
colormap(ax5,mycolormap);

ax6=nexttile([1 1]);
pcolor(peaks(50));
shading interp
xticklabels('');
yticklabels('');
h=colorbar;
h.TickLabels={};
mycolormap = customcolormap(linspace(0,1,8),mycolor(6,1));
colormap(ax6,mycolormap);

ax7=nexttile([1 1]);
pcolor(peaks(50));
shading interp
xticklabels('');
yticklabels('');
h=colorbar;
h.TickLabels={};
mycolormap = customcolormap(linspace(0,1,8),mycolor(7,1));
colormap(ax7,mycolormap);

ax8=nexttile([1 1]);
pcolor(peaks(50));
shading interp
xticklabels('');
yticklabels('');
h=colorbar;
h.TickLabels={};
mycolormap = customcolormap(linspace(0,1,8),mycolor(8,1));
colormap(ax8,mycolormap);

ax9=nexttile([1 1]);
pcolor(peaks(50));
shading interp
xticklabels('');
yticklabels('');
h=colorbar;
h.TickLabels={};
mycolormap = customcolormap(linspace(0,1,8),mycolor(9,1));
colormap(ax9,mycolormap);

ax10=nexttile([1 1]);
pcolor(peaks(50));
shading interp
xticklabels('');
yticklabels('');
h=colorbar;
h.TickLabels={};
mycolormap = customcolormap(linspace(0,1,8),mycolor(10,1));
colormap(ax10,mycolormap);

ax11=nexttile([1 1]);
pcolor(peaks(50));
shading interp
xticklabels('');
yticklabels('');
h=colorbar;
h.TickLabels={};
mycolormap = customcolormap(linspace(0,1,8),mycolor(11,1));
colormap(ax11,mycolormap);

ax12=nexttile([1 1]);
pcolor(peaks(50));
shading interp
xticklabels('');
yticklabels('');
h=colorbar;
h.TickLabels={};
mycolormap = customcolormap(linspace(0,1,8),mycolor(12,1));
colormap(ax12,mycolormap);

exportgraphics(gcf,'002.png','Resolution',600);