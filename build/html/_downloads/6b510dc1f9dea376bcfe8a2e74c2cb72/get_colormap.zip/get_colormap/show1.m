function show1
    fig=figure;
    axis off;
    %% 1
    h = colorbar;
    h.Position = [0.1,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(1,1));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.14,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(1,1),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[51,260,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(01,01)');
    uicontrol(fig,'Style','text','Position',[180,390,200,25],'String','CSDN:HappyLaber','FontSize',12);
    
    h = colorbar;
    h.Position = [0.2,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(1,2));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.24,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(1,2),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[108,260,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(01,02)');

    %% 2
    h = colorbar;
    h.Position = [0.3,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(2,1));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.34,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(2,1),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[163,260,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(02,01)');

    h = colorbar;
    h.Position = [0.4,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(2,2));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.44,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(2,2),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[220,260,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(02,02)');

    %% 3
    h = colorbar;
    h.Position = [0.5,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(3,1));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.54,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(3,1),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[277,260,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(03,01)');

    h = colorbar;
    h.Position = [0.6,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(3,2));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.64,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(3,2),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[331,260,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(03,02)');

    %% 4
    h = colorbar;
    h.Position = [0.7,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(4,1));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.74,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(4,1),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[387,260,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(04,01)');

    h = colorbar;
    h.Position = [0.8,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(4,2));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.84,0.7,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(4,2),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[445,260,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(04,02)');
    %% 5
    h = colorbar;
    h.Position = [0.1,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(5,1));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.14,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(5,1),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[51,135,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(05,01)');

    h = colorbar;
    h.Position = [0.2,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(5,2));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.24,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(5,2),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[108,135,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(05,02)');
    %% 6
    h = colorbar;
    h.Position = [0.3,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(6,1));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.34,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(6,1),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[163,135,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(06,01)');

    h = colorbar;
    h.Position = [0.4,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(6,2));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.44,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(6,2),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[220,135,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(06,02)');

    %% 7
    h = colorbar;
    h.Position = [0.5,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(7,1));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.54,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(7,1),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[277,135,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(07,01)');

    h = colorbar;
    h.Position = [0.6,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(7,2));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.64,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(7,2),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[331,135,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(07,02)');

    %% 8
    h = colorbar;
    h.Position = [0.7,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(8,1));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.74,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(8,1),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[387,135,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(08,01)');

    h = colorbar;
    h.Position = [0.8,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(8,2));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.84,0.4,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(8,2),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[445,135,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(08,02)');

    %% 9
    h = colorbar;
    h.Position = [0.1,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(9,1));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.14,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(9,1),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[51,5,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(09,01)');

    h = colorbar;
    h.Position = [0.2,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(9,2));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.24,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(9,2),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[108,5,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(09,02)');

    %% 10
    h = colorbar;
    h.Position = [0.3,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(10,1));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.34,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(10,1),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[163,5,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(10,01)');

    h = colorbar;
    h.Position = [0.4,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(10,2));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.44,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(10,2),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[220,5,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(10,02)');
    %% 11
    h = colorbar;
    h.Position = [0.5,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(11,1));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.54,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(11,1),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[277,5,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(11,01)');

    h = colorbar;
    h.Position = [0.6,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(11,2));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.64,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(11,2),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[331,5,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(11,02)');

    %% 12
    h = colorbar;
    h.Position = [0.7,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(12,1));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.74,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(12,1),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[387,5,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(12,01)');

    h = colorbar;
    h.Position = [0.8,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(12,2));
    colormap(h,mycolormap);

    h = colorbar;
    h.Position = [0.84,0.1,0.03,0.2];
    h.TickLabels={};
    mycolormap = customcolormap(linspace(0,1,8),mycolor(12,2),8);
    colormap(h,mycolormap);
    uicontrol(fig,'Style','pushbutton','Position',[445,5,50,25],'String','Copy','FontSize',12,...
        'callback',@copycode,'tag','(12,02)');

    function copycode(obj,~)
        num=obj.Tag;
        code=['mycolormap = customcolormap(linspace(0,1,8),mycolor',num,');'];
        clipboard('copy',code);
    end
end
